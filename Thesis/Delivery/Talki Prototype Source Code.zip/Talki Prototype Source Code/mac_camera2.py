# (c) 2019 Digital Sculptor GmbH, all rights reserved
# Strictly Confidential, may not be published in any form.

import os
import atexit
import face_recognition
import imutils
from PIL import Image
from pyzbar import pyzbar
import pickle
import numpy
import datetime
import time
import cv2

data = pickle.loads(
    open(os.path.join(os.path.dirname(__file__), "sight", "face-encodings"), "rb").read())

# cv2.startWindowThread()
# cv2.namedWindow("preview")

cap = cv2.VideoCapture(0)
# cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1080)
# cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
# cap.set(cv2.CAP_PROP_FRAME_WIDTH, 500)
# cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 600)
cap.set(cv2.CAP_PROP_FPS, 4)
time.sleep(0.5)
writer = None

def read_frame():
    "Read a frame(image) from the camera"
    _, image = cap.read()
    return image

def show_frame(frame, faces, barcodes):
    "Show frame as a preview with information"

    r = 1
    # loop over the recognized faces
    for ((top, right, bottom, left), name) in faces:
        # rescale the face coordinates
        top = int(top * r)
        right = int(right * r)
        bottom = int(bottom * r)
        left = int(left * r)

        # draw the predicted face name on the image
        cv2.rectangle(frame, (left, top), (right, bottom),
                      (0, 255, 0), 2)
        y = top - 15 if top - 15 > 15 else top + 15
        cv2.putText(frame, name, (left, y), cv2.FONT_HERSHEY_SIMPLEX,
                    0.75, (0, 255, 0), 2)

    for decodedObject in barcodes:
        points = decodedObject.polygon

        pts = numpy.array(points, numpy.int32)
        pts = pts.reshape((-1, 1, 2))
        cv2.polylines(frame, [pts], True, (0, 255, 0), 3)

    for bc in barcodes:
        cv2.putText(frame, bc[1].decode("utf-8") + " - " + bc[2], (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, bgr, 2)

    # cv2.imshow("Barcode Scanner", numpy.array(image, dtype = numpy.uint8))
    cv2.imshow("preview", frame)

bgr = (8, 70, 208)

def decoded_to_toy_name(decoded):
    if decoded and decoded.type is "QRCODE":
        if decoded.data.startswith(b"https://thepia.com/talki/toy/"):
            return decoded.data.replace(b"https://thepia.com/talki/toy/", b"").decode('ascii')
    return None

def check_for_barcode(image):
    return [(barcode.polygon, barcode.data, barcode.type, decoded_to_toy_name(barcode)) for barcode in barcodeReader(image)]

def barcodeReader(image):
    gray_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    barcodes = pyzbar.decode(gray_img)
    print(barcodes)

    return barcodes

def check_for_faces(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # r = frame.shape[1] / float(rgb.shape[1])

    # detect the (x, y)-coordinates of the bounding boxes
    # corresponding to each face in the input frame, then compute
    # the facial embeddings for each face
    boxes = face_recognition.face_locations(rgb, model="hog")
    encodings = face_recognition.face_encodings(rgb, boxes)
    names = []

    # loop over the facial embeddings
    for encoding in encodings:
        # attempt to match each face in the input image to our known
        # encodings
        matches = face_recognition.compare_faces(data["encodings"], encoding)
        name = "Unknown"

        # check to see if we have found a match
        if True in matches:
            # find the indexes of all matched faces then initialize a
            # dictionary to count the total number of times each face
            # was matched
            matchedIdxs = [i for (i, b) in enumerate(matches) if b]
            counts = {}

            # loop over the matched indexes and maintain a count for
            # each recognized face face
            for i in matchedIdxs:
                name = data["names"][i]
                counts[name] = counts.get(name, 0) + 1

            # determine the recognized face with the largest number
            # of votes (note: in the event of an unlikely tie Python
            # will select first entry in the dictionary)
            name = max(counts, key=counts.get)

        # update the list of names
        names.append(name)

    return (boxes, names)

def check_for_motion():
    return

def cleanup_camera():
    # do a bit of cleanup
    writer = None
    cap.release()
    cv2.destroyAllWindows()


atexit.register(cleanup_camera)
