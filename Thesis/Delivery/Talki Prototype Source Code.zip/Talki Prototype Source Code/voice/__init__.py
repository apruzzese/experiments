# (c) 2019 Digital Sculptor GmbH, all rights reserved
# Strictly Confidential, may not be published in any form.

import os, re
import simpleaudio
import memory

greetings = set([f for f in os.listdir(os.path.join(".", "sounds", "greetings")) if re.match(r'.*\.(ogg|wav)$', f)])
ask = set([f for f in os.listdir(os.path.join(".", "sounds", "ask")) if re.match(r'.*\.(ogg|wav)$', f)])
toys = set([f for f in os.listdir(os.path.join(".", "sounds", "toys")) if re.match(r'.*\.(ogg|wav)$', f)])
phonemes = set([f for f in os.listdir(os.path.join(".", "sounds", "phoneme")) if re.match(r'.*\.(ogg|wav)$', f)])

def say(sentence):
    print("saying:", sentence)
    for part in sentence:
        if isinstance(part, str):
            name = part2name(part)
            wav_filename = filename_in(greetings, "greetings", name + ".wav") or filename_in(ask, "ask", name + ".wav") or filename_in(toys, "toys", name + ".wav")
            if (wav_filename):
                wave_obj = simpleaudio.WaveObject.from_wave_file(wav_filename)
                play_obj = wave_obj.play()
                play_obj.wait_done()  # Wait until sound has finished playing

def part2name(part):
    return part.replace(",", "").replace(".", "").replace("!", "").lower().strip()

def filename_in(known_set, dirname, filename):
    if filename in known_set:
        return os.path.join(".", "sounds", dirname, filename)
    return None

def compose_greeting():
    while True:
        greeting = memory.get_next_greeting()
        if is_valid_greeting(greeting):
            return greeting

def compose_asking_for(item):
    return memory.ask_for(item)

def compose_repeat(item_name):
    return ["Grumbles....", "Can you give me a", item_name]

def compose_description(item_name):
    return ["It's a", item_name]

def is_valid_greeting(sentence):
    for part in sentence:
        if isinstance(part, str):
            name = part2name(part)
            wav_filename = filename_in(greetings, "greetings", name + ".wav")
            if wav_filename is None:
                return False
    return True

def is_valid_toy(sentence):
    if isinstance(sentence, str):
        sentence = [sentence]
    for part in sentence:
        if isinstance(part, str):
            name = part2name(part)
            wav_filename = filename_in(toys, "toys", name + ".wav")
            if wav_filename is None:
                return False
    return True

def is_valid_request(sentence):
    for part in sentence:
        if isinstance(part, str):
            name = part2name(part)
            wav_filename = filename_in(ask, "ask", name + ".wav") or filename_in(toys, "toys", name + ".wav")
            if wav_filename is None:
                return False
    return True
