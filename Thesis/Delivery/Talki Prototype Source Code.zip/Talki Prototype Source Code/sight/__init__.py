# (c) 2019 Digital Sculptor GmbH, all rights reserved
# Strictly Confidential, may not be published in any form.

import memory

recently = []

last_seen_item = None
last_item_time = memory.current_milli_time()
person_present = None
person_time = memory.current_milli_time()

callback_face = None
callback_item = None

def face_presently_seen():
    global person_present
    return person_present is not None

def callbackFaceSeen(callback):
    global callback_face
    callback_face = callback

def callbackItemSeen(callback):
    global callback_item
    callback_item = callback

# TODO Track face position/movement
# https://gist.github.com/smeschke/e59a9f5a40f0b0ed73305d34695d916b

def update_view(camera, show_video = False):
    "Update view based on camera"
    global person_present, person_time, last_seen_item, last_item_time
    now = memory.current_milli_time()
    # pir = camera.check_for_motion()
    # print("motion", pir)
    frame = camera.read_frame()
    face_boxes, face_names = camera.check_for_faces(frame)
    if len(face_names) is 0:
        # TODO if none, they have to be gone for 2 seconds
        if person_present is not None:
            print("person left.. was", person_present)
            person_time = now
            person_present = None
    else:
        # Unknown assumes the most recent known person
        # In future we need a more intelligent logic
        if face_names[0] is "Unknown" and isinstance(person_present, str):
            face_names[0] = person_present
        # New person present
        if person_present is not face_names[0]: #TODO if existing person is still there, just new joined
            print("person present,", face_names[0], "was", person_present)
            person_present = face_names[0]
            person_time = now
    if person_time is now and callable(callback_face):
        callback_face()
    barcodes = camera.check_for_barcode(frame)
    if show_video:
        camera.show_frame(frame, zip(face_boxes, face_names), barcodes)
    if len(barcodes) and barcodes[0][3]:
        last_seen_item = barcodes[0][3]
        last_item_time = now
        callback_item()


def last_change_since():
    global person_time, last_item_time
    now = memory.current_milli_time()
    return now - (max(person_time, last_item_time) or now)
    # last_change_time = person_time or last_item_time or now
    # if person_time > last_change_time:
    #     last_change_time = person_time
    # if last_item_time > last_change_time:
    #     last_change_time = last_item_time
    # return last_change_since


#TODO primary person in frame
