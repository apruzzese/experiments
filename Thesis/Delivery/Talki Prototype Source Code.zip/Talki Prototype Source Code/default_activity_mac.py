# (c) 2019 Digital Sculptor GmbH, all rights reserved
# Strictly Confidential, may not be published in any form.

import os
import time
import state, sight, voice
import mac_camera2
import cv2

class IdleState(state.TalkiState):
    """
    In this state Talki is waiting for a child to appear.
    """
    name = "Idle"

    def face_seen(self):
        # print("I see a face.", sight.person_present)
        greeting = voice.compose_greeting()
        voice.say(greeting)
        state.transition_to(SomebodyPresentState())

    def item_seen(self):
        print("Ignoring item seen.", sight.last_seen_item)


class SomebodyPresentState(state.TalkiState):
    """
    In this state Talki will wait 5 seconds to come up with something to ask for.
    """
    name = "Somebody Present"

    def child_lost_interest(self):
        transition_to(IdleState())

    @SecAfterApply(5)
    def default_request(self):
        global current_state
        if not sight.face_presently_seen():
            current_state = IdleState()
        if not sight.last_seen_item:
            self.ask_for_something()
            state.transition_to(WantingSomethingState(self.last_asked_for))


class WantingSomethingState(state.TalkiState):
    name = "Wanting Something"

    def __init__(self, last_asked_for):
        super(WantingSomethingState, self).__init__()
        self.last_asked_for = last_asked_for

    def child_lost_interest(self):
        transition_to(IdleState())

    # how to do scaling repeat of asking
    @SecAfterApply(10)
    def giving_up(self):
        if last_action_seen < memory.current_milli_time() - 10 * 1000:
            self.ask_again()

    def item_seen(self):
        if self.last_asked_for == sight.last_seen_item:
            print("Got what we asked for", sight.last_seen_item)
        else:
            print("Not the right thing", self.last_asked_for, sight.last_seen_item)


if __name__ == "__main__":
    state.transition_to(state.IdleState())
    while True:
        sight.update_view(mac_camera2, show_video = True)
        # check NFC sensor
        state.do_late_calls()
        key = cv2.waitKey(1)
        if key == 27:
            break