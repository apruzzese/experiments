# (c) 2019 Digital Sculptor GmbH, all rights reserved
# Strictly Confidential, may not be published in any form.

import os
import atexit
from picamera.array import PiRGBArray
from picamera import PiCamera
from RPi import GPIO
from threading import Thread
from imutils.video import FPS
import face_recognition
import imutils
from PIL import Image
from pyzbar import pyzbar
import pickle
import numpy
import datetime
import time
import cv2

PIR_SENSOR = 11
GPIO.setmode(GPIO.BOARD)
GPIO.setup(PIR_SENSOR, GPIO.IN)
pir_state = 0

data = pickle.loads(
    open(os.path.join(os.path.dirname(__file__), "sight", "face-encodings"), "rb").read())
detector = cv2.CascadeClassifier("/usr/local/share/opencv4/haarcascades/haarcascade_frontalface_alt.xml")

class PiVideoStream:
    def __init__(self, resolution=(320, 240), framerate=32):
        # initialize the camera and stream
        self.camera = PiCamera()
        self.camera.resolution = resolution
        self.camera.framerate = framerate
        self.rawCapture = PiRGBArray(self.camera, size=resolution)
        self.stream = self.camera.capture_continuous(self.rawCapture,
            format="bgr", use_video_port=True)

        # initialize the frame and the variable used to indicate
        # if the thread should be stopped
        self.frame = None
        self.stopped = False

    def start(self):
        # start the thread to read frames from the video stream
        t = Thread(target=self.update, args=())
        t.daemon = True
        t.start()
        return self

    def update(self):
        # keep looping infinitely until the thread is stopped
        for f in self.stream:
            # grab the frame from the stream and clear the stream in
            # preparation for the next frame
            self.frame = f.array
            self.rawCapture.truncate(0)

            # if the thread indicator variable is set, stop the thread
            # and resource camera resources
            if self.stopped:
                self.stream.close()
                self.rawCapture.close()
                self.camera.close()
                return

    def read(self):
        # return the frame most recently read
        return self.frame

    def stop(self):
        # indicate that the thread should be stopped
        self.stopped = True

vs = PiVideoStream(resolution=(640, 480), framerate=4).start()
time.sleep(2.0)
writer = None

fps = FPS().start()

def read_frame():
    "Read a frame(image) from the camera"
    return vs.frame

def show_frame(frame, faces, barcodes):
    "Show frame as a preview with information"

    # loop over the recognized faces
    for ((top, right, bottom, left), name) in faces:
        # draw the predicted face name on the image
        cv2.rectangle(frame, (left, top), (right, bottom),
                      (0, 255, 0), 2)
        y = top - 15 if top - 15 > 15 else top + 15
        cv2.putText(frame, name, (left, y), cv2.FONT_HERSHEY_SIMPLEX,
                    0.75, (0, 255, 0), 2)

    for decoded in barcodes:
        points = decoded.polygon

        pts = numpy.array(points, numpy.int32)
        pts = pts.reshape((-1, 1, 2))
        cv2.polylines(frame, [pts], True, (0, 255, 0), 3)

    for bc in barcodes:
        cv2.putText(frame, bc[1].decode("utf-8") + " - " + bc[2], (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, bgr, 2)

    # cv2.imshow("Barcode Scanner", numpy.array(image, dtype = numpy.uint8))
    cv2.imshow("preview", frame)
    fps.update()

bgr = (8, 70, 208)

def decoded_to_toy_name(decoded):
    if decoded and decoded.type is "QRCODE":
        if decoded.data.startswith(b"https://thepia.com/talki/toy/"):
            return decoded.data.replace(b"https://thepia.com/talki/toy/", b"").decode('ascii')
    return None

def check_for_barcode(image):
    return [(barcode.polygon, barcode.data, barcode.type, decoded_to_toy_name(barcode)) for barcode in barcodeReader(image)]

def barcodeReader(image):
    gray_img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    barcodes = pyzbar.decode(gray_img)

    return barcodes

def check_for_faces(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    # r = frame.shape[1] / float(rgb.shape[1])

	# detect faces in the grayscale frame
    rects = detector.detectMultiScale(gray, scaleFactor=1.1, 
		minNeighbors=5, minSize=(30, 30))

	# OpenCV returns bounding box coordinates in (x, y, w, h) order
	# but we need them in (top, right, bottom, left) order, so we
	# need to do a bit of reordering
    boxes = [(y, x + w, y + h, x) for (x, y, w, h) in rects]
 
	# compute the facial embeddings for each face bounding box
    encodings = face_recognition.face_encodings(rgb, boxes)
    names = []

    # loop over the facial embeddings
    for encoding in encodings:
        # attempt to match each face in the input image to our known
        # encodings
        matches = face_recognition.compare_faces(data["encodings"], encoding)
        name = "Unknown"

        # check to see if we have found a match
        if True in matches:
            # find the indexes of all matched faces then initialize a
            # dictionary to count the total number of times each face
            # was matched
            matchedIdxs = [i for (i, b) in enumerate(matches) if b]
            counts = {}

            # loop over the matched indexes and maintain a count for
            # each recognized face face
            for i in matchedIdxs:
                name = data["names"][i]
                counts[name] = counts.get(name, 0) + 1

            # determine the recognized face with the largest number
            # of votes (note: in the event of an unlikely tie Python
            # will select first entry in the dictionary)
            name = max(counts, key=counts.get)

        # update the list of names
        names.append(name)

    return (boxes, names)

def check_for_motion():
    global pir_state
    pir_state = GPIO.input(PIR_SENSOR)
    return pir_state

def cleanup_camera():
    # do a bit of cleanup
    writer = None
    vs.stop()
    cv2.destroyAllWindows()
    GPIO.cleanup()

atexit.register(cleanup_camera)
