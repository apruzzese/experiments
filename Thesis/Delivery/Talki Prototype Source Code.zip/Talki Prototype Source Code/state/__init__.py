# (c) 2019 Digital Sculptor GmbH, all rights reserved
# Strictly Confidential, may not be published in any form.

import time
import functools
import sight
import voice
import memory

current_state = None

def transition_to(state):
    global current_state
    if current_state:
        state.overallState = current_state.overallState
    current_state = state
    sight.callbackFaceSeen(state.face_seen)
    sight.callbackItemSeen(state.item_seen)
    queueLateCalls(state)
    print("entering", state.name, "state.")
    # print("I want to play with", state.overallState.toy_set)

def do_late_calls():
    if current_state:
        current_state.do_late_calls()

def queueLateCalls(state):
    # state.lateCalls = filter(lambda m: callable(state[m]) 
    #                          and state[m].secondsAfterApply is not None, dir(state))
    # print([m for m in dir(state) if not m.startswith('__')])
    state.lateCalls = [LateCall(getattr(state, method)) for method in dir(state) if lateCallable(method, state)]

def lateCallable(name, state):
    return not name.startswith('__') and callable(getattr(state, name)) \
           and hasattr(getattr(state, name), 'secondsAfterApply')

class LateCall(object):
    def __init__(self, method):
        self.method = method
        self.callAfter = memory.current_milli_time() + getattr(method, 'secondsAfterApply') * 1000


# Last time anything happened
last_action_seen = 0

def SecAfterApply(seconds):
    def decorator(fn):
        def decorated(*args, **kwargs):
            return fn(*args, **kwargs)
        decorated.secondsAfterApply = seconds
        return decorated
    return decorator

class Person:

    # Used to making sure that Talki doesn't speaks too much
    speakingSinceAppeared = 0
    silenceSinceAppeared = 0
    recentSpeakingTimes = []


class OverallState:
    '''
    State kept across TalkiStates
    '''
    toy_set = None

    # Set of item names that are in the set we are using
    toy_items = None

    # Toy Item I'm looking for
    toy_item = None



class TalkiState:

    name = None
    overallState = OverallState()
    lateCalls = []
    last_asked_for = None

    def __init__(self):
        self.pick_toy_set()

    def face_seen(self):
        return

    def item_seen(self):
        return

    def child_lost_interest(self):
        return

    def pick_toy_set(self):
        """Pick a set of toys among the ones I know, activity will limit to this set"""
        self.overallState.toy_set = memory.pick_toy_set()
        self.overallState.toy_items = memory.get_toy_set_names(self.overallState.toy_set)

    def ask_for_something(self):
        while True:
            item = memory.get_next_toy_name(self.overallState.toy_set)
            if voice.is_valid_toy(item):
                break
            else:
                print("not valid toy", item)
        self.overallState.toy_items.add(item)
        self.overallState.toy_item = item
        sentence = voice.compose_asking_for(item)
        voice.say(sentence)
        self.last_asked_for = memory.get_toy_name(sentence)

    def ask_again(self):
        sentence = voice.compose_repeat(self.last_asked_for)
        voice.say(sentence)

    def describe_item(self, item):
        sentence = voice.compose_description(item)
        voice.say(sentence)

    def thank_for_something(self):
        return

    def do_late_calls(self):
        future = []
        now = memory.current_milli_time()
        for call in self.lateCalls:
            if call.callAfter < now:
                call.method()
            else:
                future.append(call)
        self.lateCalls = future
        if sight.last_change_since() > 1 * 60 * 60 * 1000: # would be 5 mins in real system
            self.child_lost_interest()


